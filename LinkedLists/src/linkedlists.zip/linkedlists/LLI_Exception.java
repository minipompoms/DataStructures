package linkedlists;

/**
 *
 * @author akatz17
 */
public class LLI_Exception extends Exception
{

    /**
     *
     * @author katz95040
     */
    public LLI_Exception()
    {
        super("Error");
    }

    /**
     *
     * @param err
     */
    public LLI_Exception(String err)
    {
        super(err);
    }
}
